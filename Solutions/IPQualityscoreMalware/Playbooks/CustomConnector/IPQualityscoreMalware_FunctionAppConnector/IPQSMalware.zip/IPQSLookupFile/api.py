"""
IPQS API
"""
import logging
from os import environ

from requests import exceptions, request

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

IPQS_api_key = environ["ipqsAPIKey"]
IPQS_base_url = environ["ipqsBaseURL"]


class IPQS:
    """
    Wrapper class for IPQSRESTAPI modules and functions.
    Import this class to submit samples and retrieve reports.
    """

    def __init__(self, log):
        """
        Initialize, authenticate and healthcheck the IPQS instance,
        use IPQSConfig as configuration
        :param log: logger instance
        :return void
        """
        self.log = log or logger

    def request_ipqs_api(self, method, url, params=None, files=None):
        """
            Send an HTTP request to the IPQualityScore (IPQS) API and return the JSON response.
            method (str): The HTTP method to use (e.g., "GET", "POST").
            url (str): The API endpoint path to append to the IPQS base URL.
            params (dict, optional): Query parameters to include in the request.
            files (dict, optional): Files to include for multipart/form-data requests.
            returns Parsed JSON response from the IPQS API if the request succeeds,
            or an empty dictionary `{}` if any error or exception occurs.
            """
        try:
            response = request(
                method=method.upper(),
                url=f"{IPQS_base_url}{url}",
                params=params if not files else None,
                files=files,
                headers={"IPQS-KEY": IPQS_api_key},
                timeout=300
            )
            response.raise_for_status()  # raise error for bad responses
            return response.json()  # return parsed JSON
        except exceptions.Timeout:
            self.log.exception("[API] Request timed out")
            return {}
        except exceptions.ConnectionError:
            self.log.exception("[API] Connection error occurred")
            return {}
        except exceptions.RequestException:
            self.log.exception("[API] RequestException Issue")
            return {}
        except Exception as e:
            self.log.exception(f"[API] Unexpected exception: {e}")
            return {}
